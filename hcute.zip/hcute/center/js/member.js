$(function() {
	if(getQueryString("key") != "") {
		var a = getQueryString("key");
		var e = getQueryString("username");
		addCookie("key", a);
		addCookie("username", e)
	} else {
		var a = getCookie("key")
	}
	var vm = new Vue({
		el: "#app",
		data: {
			isLogin: a,
			memberInfor: {},
			order_count: {}
		}
	})
	if(!a) return;
	$.getJSON(ApiUrl + "/index.php?act=member_index", {
		key: a
	}, function(a) {
		checkLogin(a.login);
		vm.memberInfor = a.datas.member_info;
	});
	$.ajax({
		type: "post",
		url: ApiUrl + "/index.php?act=member_order&op=order_count",
		data: {
			key: a
		},
		dataType: "json",
		success: function(e) {
			vm.order_count = e.datas;
		}
	})
});