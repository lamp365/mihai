$(function(){
	var key = getCookie("key");
	if(isWeiXin() && !key){
		var wxcode = getPar('code');
		//console.log("wxcode: "+wxcode);
		if(wxcode){
			$("#pre-text").text("正在自动登录...");
			$.ajax({
				type: "post",
				url: ApiUrl + "/index.php?act=login&op=wx_login",
				data: {
					client: 'wechat',
					wxcode:wxcode
				},
				dataType: "json",
				success: function(e) {
                   $(".pre-loading").hide();
					if (!e.datas.error) {
						if (typeof e.datas.key == "undefined") {
							return false
						} else {
							var i = 188;
							updateCookieCart(e.datas.key);
							addCookie("username", e.datas.username);
							addCookie("key", e.datas.key);
							//delCookie("logout");
							var str = document.location.href;
							url = str.substr(0, str.indexOf('code'));
							window.location.href = url;	
						}
					}
				},
				error:function(){
					//alert('error')
				}
			})
		}else{
			$(".pre-loading").hide();
			var redirect_uri = document.location.href;
			redirect_uri=redirect_uri.replace('www\.','');
			if(redirect_uri.indexOf("demo")>0){
				var appid = 'wxfb41b83af564983a'
			}else{
			    var appid = 'wxb2ceaa63d19b1ff7';
			}
			//snsapi_userinfo
			var callback_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='+appid+'&redirect_uri=' + redirect_uri + '&response_type=code&scope=snsapi_base&state=123#wechat_redirect';
			window.location.href = callback_url;
		}		
	}else{
		$(".pre-loading").hide();
	}
})