var SiteUrl = "http://"+window.location.host+"/shop";
var ApiUrl = "http://"+window.location.host+"/mo_bile";
var pagesize = 10;
var WapSiteUrl = "http://"+window.location.host+"/wap";
///var IOSSiteUrl = "https://itunes.apple.com/us/app/shopnc-b2b2c/id879996267?l=zh&ls=1&mt=8";
var IOSSiteUrl = "";
var AndroidSiteUrl = "";
//var AndroidSiteUrl = "http://s2.shopwwi.com/download/app/AndroidShopWWIMoblie.apk";
var WeiXinOauth = true;