$(function() {
	var strUrl = window.location.href;
	var arrUrl = strUrl.split("/");
	var strPage = arrUrl[arrUrl.length - 1];
	strPage=strPage.substring(0,strPage.length-5);
	var a = getCookie("key");
	var e = '<div class="nctouch-footer-wrap posr">' + '<div class="nav-text">';
	if(a) {
		e += '<a href="' + WapSiteUrl + '/index.php" class="'+strPage+'"><i></i>首页</a>' + '<a href="' + WapSiteUrl + '/tmpl/product_first_categroy.html" class="'+strPage+'"><i></i>分类</a>' + '<a href="' + WapSiteUrl + '/tmpl/cart_list.html" class="'+strPage+'"><i></i>购物车</a>'
	} else {
		e += '<a href="' + WapSiteUrl + '/index.php" class="'+strPage+'"><i></i>首页</a>' + '<a href="' + WapSiteUrl + '/tmpl/product_first_categroy.html" class="'+strPage+'"><i></i>分类</a>' + '<a href="' + WapSiteUrl + '/tmpl/cart_list.html" class="'+strPage+'"><i></i>购物车</a>'
	}
	e += '<a href="' + WapSiteUrl + '/tmpl/member/member.html" class="'+strPage+'"><i></i>萌主</a>' + "</div>";
	$("#footer").html(e);
	var a = getCookie("key");
	$("#logoutbtn").click(function() {
		var a = getCookie("username");
		var e = getCookie("key");
		var i = "wap";
		$.ajax({
			type: "get",
			url: ApiUrl + "/index.php?act=logout",
			data: {
				username: a,
				key: e,
				client: i
			},
			success: function(a) {
				if(a) {
					delCookie("username");
					delCookie("key");
					addCookie("logout", 'logout', 0);
					location.href = "login.html";
				}
			}
		})
	})
});